# Digify Africa Website

Marketing website for Digify Africa. React 19 + TypeScript, built with Vite and styled with Tailwind CSS v4.

## Requirements

- Node.js 22
- pnpm 10

(`.mise.toml` pins these versions if you use [mise](https://mise.jdx.dev).)

## Run locally

```bash
pnpm install
pnpm dev        # dev server with hot reload
pnpm build      # production build into dist/
pnpm preview    # serve the production build locally
```

## Structure

- `index.html` – HTML shell, page title, meta tags, favicon
- `src/main.tsx` – React entry point
- `src/App.tsx` – the site's sections and components
- `src/index.css` – global styles, Tailwind import, colour variables, fonts
- `public/` – static files (favicon, logo, hero image, robots.txt)
- `vite.config.ts` – Vite configuration

## Before launch

The site is currently set to stay out of search results:

- `<meta name="robots" content="noindex, nofollow">` in `index.html`
- `public/robots.txt` blocks all crawlers

Remove both when the site goes live.
