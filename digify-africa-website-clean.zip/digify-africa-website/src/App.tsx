import { FormEvent, useEffect, useState } from "react";

type I =
  | "arrow"
  | "book"
  | "briefcase"
  | "building"
  | "chat"
  | "check"
  | "globe"
  | "heart"
  | "menu"
  | "people"
  | "spark"
  | "x";
function Icon({ n, s = 22 }: { n: I; s?: number }) {
  const p: Record<I, React.ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14" />
        <path d="m13 6 6 6-6 6" />
      </>
    ),
    book: (
      <>
        <path d="M4 5a2 2 0 0 1 2-2h5v16H6a2 2 0 0 0-2 2z" />
        <path d="M20 5a2 2 0 0 0-2-2h-5v16h5a2 2 0 0 1 2 2z" />
      </>
    ),
    briefcase: (
      <>
        <rect x="3" y="7" width="18" height="13" rx="2" />
        <path d="M8 7V5h8v2M3 12h18" />
      </>
    ),
    building: (
      <>
        <path d="M4 21V4h11v17M15 9h5v12M8 8h3M8 12h3M8 16h3M2 21h20" />
      </>
    ),
    chat: (
      <>
        <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" />
        <path d="M8 10h.01M12 10h.01M16 10h.01" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    globe: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" />
      </>
    ),
    heart: (
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-8 7.8L12 21l8-8.6a5.5 5.5 0 0 0 .8-7.8z" />
    ),
    menu: <path d="M4 7h16M4 12h16M4 17h16" />,
    people: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-4" />
      </>
    ),
    spark: (
      <>
        <path d="m12 3-1.3 4.2L7 9l3.7 1.8L12 15l1.3-4.2L17 9l-3.7-1.8z" />
        <path d="m5 15-.7 2.3L2 18.5l2.3 1.2L5 22l.7-2.3L8 18.5l-2.3-1.2z" />
      </>
    ),
    x: <path d="m6 6 12 12M18 6 6 18" />,
  };
  return (
    <svg
      aria-hidden="true"
      width={s}
      height={s}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {p[n]}
    </svg>
  );
}

type Page = { title: string; eyebrow: string; intro: string; kind: string };
const pages: Record<string, Page> = {
  "/learn": {
    title: "Learn digital skills",
    eyebrow: "Learning journey",
    intro:
      "Build practical, in-demand digital skills through programmes designed for Africa’s realities.",
    kind: "learning",
  },
  "/find-work": {
    title: "Find work and earning opportunities",
    eyebrow: "For learners & graduates",
    intro:
      "Move from learning to earning with career resources and opportunities for Digify graduates.",
    kind: "work",
  },
  "/find-talent": {
    title: "Find digital talent",
    eyebrow: "For employers",
    intro:
      "Connect with job-ready digital talent trained through Digify Africa’s practical programmes.",
    kind: "talent",
  },
  "/partner": {
    title: "Fund or partner with Digify",
    eyebrow: "For partners",
    intro: "Work with us to expand access to relevant digital skills and sustainable livelihoods.",
    kind: "partner",
  },
  "/build-programme": {
    title: "Build a learning programme",
    eyebrow: "Custom learning",
    intro:
      "Co-create accessible, mobile-first learning experiences for your community or organisation.",
    kind: "partner",
  },
  "/technology": {
    title: "Learning technology",
    eyebrow: "DigiBots",
    intro:
      "Reach learners where they are through accessible learning experiences delivered on WhatsApp.",
    kind: "tech",
  },
  "/case-studies": {
    title: "Case studies",
    eyebrow: "Stories of change",
    intro:
      "Explore how practical learning and thoughtful partnerships create pathways to opportunity.",
    kind: "stories",
  },
  "/donate": {
    title: "Help create the next opportunity",
    eyebrow: "Donate",
    intro:
      "Support Digify Africa’s mission to bring digital skills to young people across communities.",
    kind: "donate",
  },
  "/about": {
    title: "Digital skills for Africa’s future",
    eyebrow: "About us",
    intro:
      "Digify Africa is a youth-led organisation at the forefront of shaping Africa’s digital future.",
    kind: "about",
  },
  "/impact": {
    title: "Changing lives through digital skills",
    eyebrow: "Our impact",
    intro: "We build skills that are in demand and support pathways to sustainable livelihoods.",
    kind: "impact",
  },
  "/people": {
    title: "The people behind the mission",
    eyebrow: "Our people",
    intro:
      "Meet the team working to make practical digital learning more accessible across Africa.",
    kind: "people",
  },
  "/academy": {
    title: "Welcome to the Academy",
    eyebrow: "Academy",
    intro:
      "Explore demand-driven training for young people, entrepreneurs, educators and communities.",
    kind: "programmes",
  },
  "/programmes": {
    title: "Find a programme that fits",
    eyebrow: "Academy programmes",
    intro: "Compare Digify Africa’s learning programmes and choose your next step.",
    kind: "programmes",
  },
  "/programmes/digify-pro-online": {
    title: "Digify Pro Online",
    eyebrow: "Programme",
    intro:
      "An immersive digital skills programme supporting unemployed youth preparing to enter the digital industry.",
    kind: "programme",
  },
  "/programmes/digify-bytes": {
    title: "Digify Bytes",
    eyebrow: "Programme",
    intro: "Community-based digital learning designed to expand access to essential skills.",
    kind: "programme",
  },
  "/programmes/lesedi": {
    title: "Lesedi Learning Bot",
    eyebrow: "DigiBot",
    intro: "A WhatsApp experience developed to make digital learning easier to access.",
    kind: "bot",
  },
  "/programmes/lwazi": {
    title: "Lwazi Learning Bot",
    eyebrow: "DigiBot",
    intro: "Learning delivered through the familiar, low-data WhatsApp environment.",
    kind: "bot",
  },
  "/programmes/kitso": {
    title: "Kitso Learning Bot",
    eyebrow: "DigiBot",
    intro: "Learn essential digital literacy and online safety skills through WhatsApp.",
    kind: "bot",
  },
  "/chat-bots": {
    title: "Chat bots built for learning",
    eyebrow: "DigiBots",
    intro: "Human-centred conversational learning that helps organisations reach more people.",
    kind: "tech",
  },
  "/hire-a-grad": {
    title: "Hire a Digify graduate",
    eyebrow: "Hire a grad",
    intro: "Find emerging digital talent with practical training and a readiness to contribute.",
    kind: "talent",
  },
  "/news": {
    title: "News from Digify Africa",
    eyebrow: "News",
    intro: "Updates on our programmes, partnerships and work across the continent.",
    kind: "stories",
  },
  "/events": {
    title: "Learn, connect and take part",
    eyebrow: "Events",
    intro: "Discover Digify Africa learning sessions, conversations and community events.",
    kind: "events",
  },
  "/media": {
    title: "Digify Africa in the media",
    eyebrow: "Media coverage",
    intro: "Coverage and conversations about digital inclusion, learning and opportunity.",
    kind: "stories",
  },
  "/industry-analysis": {
    title: "Ideas shaping Africa’s digital future",
    eyebrow: "Industry analysis",
    intro: "Perspectives on digital skills, learning technology and the future of work.",
    kind: "stories",
  },
  "/contact": {
    title: "Let’s start a conversation",
    eyebrow: "Contact",
    intro: "Tell us what you’re looking for and the right Digify Africa team will get back to you.",
    kind: "contact",
  },
};
const programmes = [
  {
    name: "Digify Pro Online",
    text: "Immersive, practical digital marketing training for unemployed youth.",
    tag: "Career skills",
    to: "/programmes/digify-pro-online",
  },
  {
    name: "Digify Bytes",
    text: "Accessible community-based learning that builds essential digital skills.",
    tag: "Community learning",
    to: "/programmes/digify-bytes",
  },
  {
    name: "Kitso",
    text: "Digital literacy and online safety learning through WhatsApp.",
    tag: "WhatsApp learning",
    to: "/programmes/kitso",
  },
];
function go(to: string) {
  history.pushState({}, "", to);
  dispatchEvent(new PopStateEvent("popstate"));
  scrollTo({ top: 0, behavior: "smooth" });
}
function Btn({
  to,
  children,
  alt = false,
}: {
  to: string;
  children: React.ReactNode;
  alt?: boolean;
}) {
  return (
    <button className={`btn ${alt ? "alt" : ""}`} onClick={() => go(to)}>
      {children}
      <Icon n="arrow" s={18} />
    </button>
  );
}
function Heading({
  eyebrow,
  title,
  text,
  light = false,
}: {
  eyebrow: string;
  title: string;
  text?: string;
  light?: boolean;
}) {
  return (
    <div className={`heading ${light ? "light" : ""}`}>
      <p className="eyebrow">{eyebrow}</p>
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </div>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  const nav = [
    ["Learn", "/learn"],
    ["About", "/about"],
    ["Find Talent", "/find-talent"],
    ["Partner With Us", "/partner"],
    ["Donate", "/donate"],
    ["Contact", "/contact"],
  ];
  return (
    <header>
      <div className="utility">
        <div className="wrap">
          Digital skills for Africa’s future{" "}
          <a href="mailto:digital@digifyafrica.com">digital@digifyafrica.com</a>
        </div>
      </div>
      <div className="wrap nav">
        <button className="logo" onClick={() => go("/")}>
          <img src="/assets/digify-logo.png" alt="Digify Africa" />
        </button>
        <nav>
          {nav.map((x) => (
            <button key={x[1]} onClick={() => go(x[1])}>
              {x[0]}
            </button>
          ))}
        </nav>
        <button className="hamb" aria-label="Toggle menu" onClick={() => setOpen(!open)}>
          <Icon n={open ? "x" : "menu"} />
        </button>
      </div>
      {open && (
        <div className="mobile-menu">
          {nav.map((x) => (
            <button
              key={x[1]}
              onClick={() => {
                setOpen(false);
                go(x[1]);
              }}
            >
              {x[0]}
              <Icon n="arrow" s={17} />
            </button>
          ))}
        </div>
      )}
    </header>
  );
}
function Footer() {
  return (
    <footer>
      <div className="wrap foot">
        <div className="foot-brand">
          <img src="/assets/digify-logo.png" alt="Digify Africa" />
          <p>Bringing practical digital skills to young people across African communities.</p>
          <a href="mailto:digital@digifyafrica.com">digital@digifyafrica.com</a>
        </div>
        {[
          [
            "Explore",
            [
              ["About us", "/about"],
              ["Our impact", "/impact"],
              ["Our people", "/people"],
              ["Case studies", "/case-studies"],
            ],
          ],
          [
            "Learn",
            [
              ["Academy", "/academy"],
              ["Programmes", "/programmes"],
              ["DigiBots", "/technology"],
              ["Find work", "/find-work"],
            ],
          ],
          [
            "Work with us",
            [
              ["Find talent", "/find-talent"],
              ["Hire a grad", "/hire-a-grad"],
              ["Partner", "/partner"],
              ["Build a programme", "/build-programme"],
              ["Contact", "/contact"],
            ],
          ],
          [
            "Stories & insights",
            [
              ["News", "/news"],
              ["Events", "/events"],
              ["Media coverage", "/media"],
              ["Industry analysis", "/industry-analysis"],
            ],
          ],
        ].map((c: any) => (
          <div key={c[0]}>
            <h3>{c[0]}</h3>
            {c[1].map((x: string[]) => (
              <button key={x[1]} onClick={() => go(x[1])}>
                {x[0]}
              </button>
            ))}
          </div>
        ))}
      </div>
      <div className="wrap legal">
        <span>Digify Foundation (RF) NPC · Registration No. 2012/049775/08</span>
        <span>Johannesburg, South Africa</span>
      </div>
    </footer>
  );
}

function Didi() {
  const [open, setOpen] = useState(false),
    [route, setRoute] = useState("");
  const opts = [
    ["I want to learn", "/learn"],
    ["I’m a Digify graduate", "/find-work"],
    ["I need digital talent", "/find-talent"],
    ["I represent an organisation", "/partner"],
  ];
  return (
    <>
      <button className="didi" onClick={() => setOpen(true)}>
        <i>
          <Icon n="spark" s={18} />
        </i>
        Ask Didi
      </button>
      {open && (
        <div className="shade" onClick={() => setOpen(false)}>
          <section
            className="dialog"
            role="dialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >
            <button className="close" onClick={() => setOpen(false)}>
              <Icon n="x" />
            </button>
            <i className="didi-icon">
              <Icon n="spark" />
            </i>
            <p className="eyebrow">Didi Guide</p>
            <h2>{route ? "Here’s where to start" : "Let’s find your best next step"}</h2>
            {route ? (
              <>
                <p>We’ve found a pathway designed around your goal.</p>
                <button
                  className="btn wide"
                  onClick={() => {
                    setOpen(false);
                    go(route);
                  }}
                >
                  View my pathway <Icon n="arrow" />
                </button>
                <button className="text-btn" onClick={() => setRoute("")}>
                  Start again
                </button>
              </>
            ) : (
              <>
                <p>Choose the option that sounds most like you.</p>
                <div className="choices">
                  {opts.map((x) => (
                    <button key={x[1]} onClick={() => setRoute(x[1])}>
                      {x[0]}
                      <Icon n="arrow" s={17} />
                    </button>
                  ))}
                </div>
              </>
            )}
            <small>Didi provides pathway guidance only, not admissions or career advice.</small>
          </section>
        </div>
      )}
    </>
  );
}

function Home() {
  const paths = [
    ["book", "01", "Learn Digital Skills", "Explore practical, in-demand programmes.", "/learn"],
    [
      "people",
      "02",
      "Hire Digital Talent",
      "Meet emerging talent ready to contribute.",
      "/find-talent",
    ],
    ["heart", "03", "Partner With Digify", "Create meaningful reach and impact.", "/partner"],
    [
      "building",
      "04",
      "Build a Learning Programme",
      "Co-create learning for your community.",
      "/build-programme",
    ],
  ];
  return (
    <main id="main">
      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <p className="eyebrow">Digital skills for Africa’s future</p>
            <h1>
              From access
              <br />
              to <em>opportunity.</em>
            </h1>
            <p>
              We help young people build relevant digital skills, prove what they can do and connect
              to pathways for sustainable livelihoods.
            </p>
            <div className="actions">
              <Btn to="/learn">Start learning</Btn>
              <Btn to="/about" alt>
                Discover our work
              </Btn>
            </div>
            <div className="trust">
              <i>
                <Icon n="globe" s={18} />
              </i>
              <span>
                <b>Across 10 African countries</b>
                <br />
                Learning designed for local realities
              </span>
            </div>
          </div>
          <div className="hero-img">
            <b />
            <img
              src="/assets/digify-hero.jpg"
              alt="A young African woman learning at her computer"
            />
            <span>
              <Icon n="spark" />
              <small>
                Skills that move
                <br />
                <strong>people forward</strong>
              </small>
            </span>
          </div>
        </div>
      </section>
      <section className="section pathways">
        <div className="wrap">
          <Heading
            eyebrow="Choose your pathway"
            title="What would you like to do today?"
            text="Start with your goal. We’ll help you find the right route."
          />
          <div className="path-grid">
            {paths.map((x: any) => (
              <button key={x[1]} onClick={() => go(x[4])}>
                <div>
                  <i>
                    <Icon n={x[0]} />
                  </i>
                  <small>{x[1]}</small>
                </div>
                <h3>{x[2]}</h3>
                <p>{x[3]}</p>
                <b>
                  Explore this pathway <Icon n="arrow" s={17} />
                </b>
              </button>
            ))}
          </div>
          <div className="grad">
            <i>
              <Icon n="briefcase" />
            </i>
            <div>
              <strong>Already a Digify learner or graduate?</strong>
              <p>Explore work and earning opportunities designed to help you take the next step.</p>
            </div>
            <Btn to="/find-work" alt>
              Find opportunities
            </Btn>
          </div>
        </div>
      </section>
      <section className="section model">
        <div className="wrap">
          <Heading
            light
            eyebrow="Our model"
            title="How Digify works"
            text="A connected journey from first access to meaningful opportunity."
          />
          <div className="steps">
            {[
              ["Access", "Meet learners where they are."],
              ["Capability", "Build practical, applied skills."],
              ["Proof", "Demonstrate confidence and readiness."],
              ["Opportunity", "Connect learning to livelihoods."],
            ].map((x, i) => (
              <div key={x[0]}>
                <span>0{i + 1}</span>
                <h3>{x[0]}</h3>
                <p>{x[1]}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="wrap">
          <div className="title-row">
            <Heading
              eyebrow="Featured programmes"
              title="Skills for where you are — and where you’re going"
            />
            <Btn to="/programmes" alt>
              View all programmes
            </Btn>
          </div>
          <ProgrammeCards />
        </div>
      </section>
      <section className="section tech">
        <div className="wrap two">
          <Phone />
          <div>
            <Heading
              light
              eyebrow="Learning technology"
              title="Learning that fits in your pocket"
              text="Our DigiBots bring accessible learning to WhatsApp — a familiar platform learners already use."
            />
            <ul>
              {[
                "Familiar, mobile-first learning",
                "Practical lessons in manageable steps",
                "Designed for reach and accessibility",
              ].map((x) => (
                <li key={x}>
                  <Icon n="check" />
                  {x}
                </li>
              ))}
            </ul>
            <Btn to="/technology">Explore DigiBots</Btn>
          </div>
        </div>
      </section>
      <section className="section impact">
        <div className="wrap two">
          <div>
            <Heading
              eyebrow="Our impact"
              title="Digital skills. Human outcomes."
              text="We focus on practical learning that helps young people participate in the digital economy."
            />
            <div className="stat">
              <strong>10</strong>
              <span>
                African countries reached<small>Verified on Digify Africa’s current website</small>
              </span>
            </div>
            <Btn to="/impact" alt>
              See our impact
            </Btn>
          </div>
          <aside>
            <p className="eyebrow">Impact report</p>
            <h3>2025 Impact Report</h3>
            <p>Detailed report information is not yet available in approved source content.</p>
            <button disabled>Report coming soon</button>
          </aside>
        </div>
      </section>
      <section className="section stories">
        <div className="wrap">
          <Heading
            eyebrow="Stories & insights"
            title="What change looks like"
            text="Programme updates, learning insights and stories from our community."
          />
          <article>
            <img
              src="https://images.unsplash.com/photo-1683199804561-ce75c2c7bf61?auto=format&fit=crop&w=1200&q=82"
              alt="Young African professionals learning together"
            />
            <div>
              <span className="pill">Industry analysis</span>
              <h3>Transitioning from learning to earning</h3>
              <p>Exploring economic pathways for young people in the digital economy.</p>
              <button onClick={() => go("/industry-analysis")}>
                Read the story <Icon n="arrow" />
              </button>
            </div>
          </article>
        </div>
      </section>
      <section className="final">
        <div className="wrap">
          <p className="eyebrow">Your next step starts here</p>
          <h2>
            Let’s turn potential
            <br />
            into <em>possibility.</em>
          </h2>
          <p>Whether you want to learn, hire, partner or support — there’s a place for you.</p>
          <Btn to="/learn">Explore learning</Btn>{" "}
          <Btn to="/partner" alt>
            Partner with us
          </Btn>
        </div>
      </section>
    </main>
  );
}
function Phone() {
  return (
    <div className="phone">
      <strong>DigiBot learning</strong>
      <p>Welcome! Ready for today’s lesson?</p>
      <p className="me">Yes, let’s learn.</p>
      <p>Great. We’ll take it one practical step at a time.</p>
      <span>Type a message…</span>
    </div>
  );
}
function ProgrammeCards() {
  return (
    <div className="program-grid">
      {programmes.map((p, i) => (
        <article className={`pc p${i}`} key={p.name}>
          <span>{p.tag}</span>
          <div>
            <h3>{p.name}</h3>
            <p>{p.text}</p>
            <button onClick={() => go(p.to)}>
              Explore programme <Icon n="arrow" s={18} />
            </button>
          </div>
        </article>
      ))}
    </div>
  );
}

function Form({ type = "contact" }: { type?: string }) {
  const [done, setDone] = useState(false),
    [errors, setErrors] = useState<Record<string, string>>({});
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const d = new FormData(e.currentTarget),
      er: Record<string, string> = {};
    if (!d.get("name")) er.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(d.get("email"))))
      er.email = "Enter a valid email.";
    if (!d.get("message")) er.message = "Please tell us how we can help.";
    setErrors(er);
    if (!Object.keys(er).length) setDone(true);
  }
  if (done)
    return (
      <div className="success">
        <i>
          <Icon n="check" />
        </i>
        <h3>Thank you — your enquiry is ready.</h3>
        <p>This prototype does not send data, but the validation and success state are working.</p>
        <button className="text-btn" onClick={() => setDone(false)}>
          Send another enquiry
        </button>
      </div>
    );
  return (
    <form onSubmit={submit} noValidate>
      <div className="fields">
        <label>
          Full name
          <input name="name" aria-invalid={!!errors.name} />
          {errors.name && <small>{errors.name}</small>}
        </label>
        <label>
          Email address
          <input name="email" type="email" aria-invalid={!!errors.email} />
          {errors.email && <small>{errors.email}</small>}
        </label>
      </div>
      <label>
        I’m interested in
        <select name="interest" defaultValue={type}>
          <option value="contact">General enquiry</option>
          <option value="employer">Hiring digital talent</option>
          <option value="partner">Funding or partnership</option>
          <option value="demo">DigiBot demo</option>
          <option value="learner">Learner profile</option>
        </select>
      </label>
      <label>
        How can we help?
        <textarea name="message" rows={5} aria-invalid={!!errors.message} />
        {errors.message && <small>{errors.message}</small>}
      </label>
      <label className="consent">
        <input type="checkbox" required />
        <span>I agree that Digify Africa may use these details to respond.</span>
      </label>
      <button className="btn">
        Send enquiry <Icon n="arrow" />
      </button>
    </form>
  );
}
function Listing({ kind }: { kind: string }) {
  if (["programmes", "learning"].includes(kind))
    return (
      <>
        <div className="filters">
          <button>All programmes</button>
          <button>Career skills</button>
          <button>Digital literacy</button>
          <button>Mobile learning</button>
        </div>
        <ProgrammeCards />
      </>
    );
  if (kind === "stories")
    return (
      <div className="cards">
        {[
          "Rebuilding trust in learning",
          "Bridging the digital divide — one WhatsApp chat at a time",
          "Bots with soul: scaling learning across the continent",
        ].map((x, i) => (
          <article key={x}>
            <span className="pill">{i ? "News" : "Insight"}</span>
            <h3>{x}</h3>
            <p>Read the latest thinking and updates from Digify Africa.</p>
            <button>
              Read article <Icon n="arrow" />
            </button>
          </article>
        ))}
      </div>
    );
  return null;
}
function Programme({ p }: { p: Page }) {
  const pro = p.title === "Digify Pro Online";
  return (
    <div className="detail">
      <div>
        <Heading
          eyebrow="Programme overview"
          title="Build skills you can put into practice"
          text={
            pro
              ? "Digify Pro develops skills across digital marketing, content, social media, SEO, email marketing, analytics and digital entrepreneurship."
              : "Practical, guided digital learning designed for accessibility."
          }
        />
        <h3>What you’ll gain</h3>
        {[
          "Practical, relevant digital knowledge",
          "Guided learning and applied activities",
          "A pathway towards further opportunity",
        ].map((x) => (
          <p className="tick" key={x}>
            <Icon n="check" />
            {x}
          </p>
        ))}
      </div>
      <aside className="facts">
        <h3>Programme details</h3>
        {[
          ["Eligibility", pro ? "Unemployed youth" : "See application information"],
          ["Country", "Programme dependent"],
          ["Cost", "See current application"],
          ["Format", pro ? "Online" : "Mobile-first"],
          ["Duration", "To be confirmed"],
          ["Dates", "To be confirmed"],
          ["Status", "Check availability"],
        ].map((x) => (
          <p key={x[0]}>
            <span>{x[0]}</span>
            <b>{x[1]}</b>
          </p>
        ))}
        <Btn to="/contact">Ask about this programme</Btn>
      </aside>
    </div>
  );
}

function Inner({ p }: { p: Page }) {
  const formType =
    p.kind === "talent"
      ? "employer"
      : p.kind === "partner"
        ? "partner"
        : p.kind === "tech"
          ? "demo"
          : "contact";
  const special = ["contact", "talent", "partner", "donate"].includes(p.kind);
  return (
    <main id="main">
      <section className={`page-hero ${["tech", "bot"].includes(p.kind) ? "dark" : ""}`}>
        <div className="wrap">
          <div>
            <p className="eyebrow">{p.eyebrow}</p>
            <h1>{p.title}</h1>
            <p>{p.intro}</p>
          </div>
          <i>
            <Icon
              n={
                p.kind === "tech"
                  ? "chat"
                  : p.kind === "talent" || p.kind === "work"
                    ? "briefcase"
                    : p.kind === "donate"
                      ? "heart"
                      : "spark"
              }
              s={40}
            />
          </i>
        </div>
      </section>
      <section className="section inner">
        <div className="wrap">
          {["programme", "bot"].includes(p.kind) && <Programme p={p} />}
          <Listing kind={p.kind} />
          {p.kind === "about" && (
            <div className="editorial">
              <div>
                <Heading
                  eyebrow="Our mission"
                  title="Closing the gap between access and opportunity"
                  text="Digify Africa brings digital skills to young people across communities through practical, demand-driven programmes and training."
                />
                <Btn to="/impact">Explore our impact</Btn>
              </div>
              <img src="/assets/digify-hero.jpg" alt="A Digify Africa learner" />
            </div>
          )}
          {p.kind === "impact" && (
            <div className="impact-page">
              <div>
                <strong>10</strong>
                <span>African countries</span>
                <small>Confirmed on Digify Africa’s current website</small>
              </div>
              <div>
                <h2>Impact with integrity</h2>
                <p>
                  Digify Africa helps young Africans build skills that are in demand and enables
                  sustainable livelihoods in the digital economy.
                </p>
                <p>
                  Additional statistics are intentionally withheld until an approved, current source
                  is available.
                </p>
                <aside>
                  <b>2025 Impact Report</b>
                  <span>Coming soon — details unavailable in approved content.</span>
                </aside>
              </div>
            </div>
          )}
          {p.kind === "people" && (
            <Empty
              title="People profiles will appear here"
              text="Approved names, roles and photography were not available, so no staff details have been invented."
            />
          )}
          {p.kind === "events" && (
            <Empty
              title="New events will appear here"
              text="No approved upcoming event dates are currently available. Contact us to hear about future sessions."
            />
          )}
          {p.kind === "tech" && (
            <div className="editorial">
              <Phone />
              <div>
                <Heading
                  eyebrow="Mobile-first by design"
                  title="Accessible learning, at meaningful scale"
                  text="DigiBots use conversational learning to deliver content through WhatsApp. The portfolio includes Lesedi, Lwazi and Kitso."
                />
                <div className="botlinks">
                  {["Lesedi", "Lwazi", "Kitso"].map((x) => (
                    <button onClick={() => go(`/programmes/${x.toLowerCase()}`)}>
                      {x}
                      <Icon n="arrow" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
          {p.kind === "work" && (
            <>
              <div className="journey">
                {[
                  "Build your learner profile",
                  "Prepare your portfolio",
                  "Explore earning pathways",
                ].map((x, i) => (
                  <article>
                    <span>0{i + 1}</span>
                    <h3>{x}</h3>
                    <p>Practical guidance for your next step after learning.</p>
                  </article>
                ))}
              </div>
              <div className="form-band">
                <h2>Create a learner enquiry</h2>
                <Form type="learner" />
              </div>
            </>
          )}
          {special && (
            <div className="form-layout">
              <div>
                <p className="eyebrow">
                  {p.kind === "donate" ? "Support the mission" : "Get in touch"}
                </p>
                <h2>
                  {p.kind === "donate"
                    ? "Tell us how you’d like to support"
                    : "Start with a short enquiry"}
                </h2>
                <p>
                  {p.kind === "donate"
                    ? "Online payment details were not available. Send an enquiry for verified giving options."
                    : "Share a few details and we’ll route your question."}
                  <br />
                  <br />
                  <b>Email</b>
                  <br />
                  <a href="mailto:digital@digifyafrica.com">digital@digifyafrica.com</a>
                  <br />
                  <br />
                  <b>Location</b>
                  <br />
                  Johannesburg, South Africa
                </p>
              </div>
              <Form type={formType} />
            </div>
          )}
        </div>
      </section>
      <section className="inner-cta">
        <div className="wrap">
          <h2>Not sure where to begin?</h2>
          <p>Ask Didi Guide to find your pathway.</p>
          <button
            className="btn alt"
            onClick={() => document.querySelector<HTMLButtonElement>(".didi")?.click()}
          >
            Open Didi Guide <Icon n="spark" />
          </button>
        </div>
      </section>
    </main>
  );
}
function Empty({ title, text }: { title: string; text: string }) {
  return (
    <div className="empty">
      <p className="eyebrow">Information placeholder</p>
      <h2>{title}</h2>
      <p>{text}</p>
      <Btn to="/contact">Contact Digify Africa</Btn>
    </div>
  );
}
export default function App() {
  const [path, setPath] = useState(location.pathname);
  useEffect(() => {
    const f = () => setPath(location.pathname);
    addEventListener("popstate", f);
    return () => removeEventListener("popstate", f);
  }, []);
  return (
    <>
      <a className="skip" href="#main">
        Skip to content
      </a>
      <Header />
      {path === "/" ? (
        <Home />
      ) : (
        <Inner
          p={
            pages[path] || {
              title: "Page not found",
              eyebrow: "404",
              intro: "The page you’re looking for does not exist.",
              kind: "unknown",
            }
          }
        />
      )}
      <Footer />
      <Didi />
    </>
  );
}
